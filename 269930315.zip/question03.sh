echo "Your content here" > file3.txt
git add file3.txt
