git checkout branch2
git stash pop
git add file4
git commit -m "Restore and commit uncommitted changes to file4"
