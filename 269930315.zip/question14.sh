cd git-practice-04
git fetch origin
git checkout update1
git branch
