git add *.py
git commit -m "Python files"

