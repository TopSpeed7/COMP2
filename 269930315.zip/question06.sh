git add -u
git commit -m "Hello"
