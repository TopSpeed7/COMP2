cd git-practice-02
git fetch origin
git checkout branch2
git merge branch3
git add <resolved_file>
git commit -m "Merged branch3 into branch2 and resolved conflicts"
git branch -d branch3
