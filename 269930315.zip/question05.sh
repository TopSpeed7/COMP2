mkdir dir1
echo "Hello" > dir1/file2
git add dir1
