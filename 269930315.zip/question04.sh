git commit -m "commit message"
