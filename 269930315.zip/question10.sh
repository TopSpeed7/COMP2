git switch main
git merge branch1
